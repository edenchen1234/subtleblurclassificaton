import os
import numpy as np
import cv2
from torch.utils.data import Dataset
from torchvision import transforms
from PIL import Image
import torch
import PIL
import os
import torchdft
import sobel
class dataloader():
    def __init__(self, data_dir):
        self.data_dir = data_dir
        if not os.path.exists(data_dir):
            raise RuntimeError("dataset error:", data_dir + 'not exists')
        self.data_name_list = []
        for _, _, file_names in os.walk(self.data_dir):
            for fileName in file_names:
                self.data_name_list.append(os.path.join(self.data_dir, fileName))
        return

    def togray(self):
        for i in self.data_name_list:
            img = cv2.imread(i,-1)
            if img.ndim != 2:
                if img.shape[2] == 3:
                    img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
                elif img.shape[2] == 4:
                    img = cv2.cvtColor(img, cv2.COLOR_RGBA2GRAY)
            img = cv2.imwrite(i, img)
            print(i)
        return
    
class myDataSet(Dataset):
    def __init__(self, root, transform):
        self.image_files = np.array([x.path for x in os.scandir(root)
                                     if x.name.endswith(".jpg") or x.name.endswith(".png") or x.name.endswith(".JPG")])
        self.transform = transform

    def __getitem__(self, item):
        x = Image.open(self.image_files[item])
        x = self.transform(x)
        freq = torchdft.torchdft(x)
        x1 = sobel.s1(x)
        x2 = sobel.s2(x)
        x3 = sobel.s3(x)
        x4 = sobel.s4(x)
        x5 = sobel.s5(x)
        x6 = sobel.s6(x)
        x7 = sobel.s7(x)
        x8 = sobel.s8(x)
        x1 = torch.cat((x1,x2),0)
        x1 = torch.cat((x1,x3),0)
        x1 = torch.cat((x1,x4),0)
        x1 = torch.cat((x1,x5),0)
        x1 = torch.cat((x1,x6),0)
        x1 = torch.cat((x1,x7),0)
        x1 = torch.cat((x1,x8),0)
        thisLabel =1
        if "mb" in self.image_files[item]:
            thisLabel = 0
        elif "good" in self.image_files[item]:
            thisLabel = 2
        return x, freq, x1, thisLabel

    def __len__(self):
        return len(self.image_files)

if __name__ == '__main__':

    data = dataloader("C:/Users/Administrator/Desktop/lunwen/s")
    data.togray()
    
    # data_transform = transforms.Compose([

    #     transforms.Resize(size=(512,512)),
    #     transforms.ToTensor(),
    #     transforms.Normalize([0.5], [0.5])
    # ])
    # data = myDataSet("D:\dataset01\BlurDatasetImage\image2\outoffocus", transform=data_transform)
    # print(data.__getitem__(1))
    # data.image_files
