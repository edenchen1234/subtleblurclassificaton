import torch.nn as nn
import torch.nn.functional as F
import torch

class basic_block(nn.Module):
    '''定义了带实线部分的残差块'''
    def __init__(self,in_channels):
        super(basic_block, self).__init__()
        self.conv1 = nn.Conv2d(in_channels,in_channels,kernel_size=3,stride=1,padding=1)
        self.conv2 = nn.Conv2d(in_channels,in_channels,kernel_size=3,stride=1,padding=1)
    def forward(self, x):
        y = F.relu(self.conv1(x))
        y = self.conv2(y)
        return F.relu(x+y)
    

class basic_block2(nn.Module):
    '''定义了带虚线部分的残差块'''
    def __init__(self,in_channels,out_channels):
        super(basic_block2, self).__init__()
        self.conv1 = nn.Conv2d(in_channels,out_channels,kernel_size=1,stride=2)
        self.conv2 = nn.Conv2d(in_channels,out_channels,kernel_size=3,stride=2,padding=1)
        self.conv3 = nn.Conv2d(out_channels,out_channels,kernel_size=3,stride=1,padding=1)
    def forward(self, x):
        z = self.conv1(x)
        y = F.relu(self.conv2(x))
        y = self.conv3(y)
        return F.relu(y+z)


class resnet(nn.Module):
    '''按照网络结构图直接连接，确定好通道数量就可以'''
    def __init__(self,num_classes=2):
        super(resnet, self).__init__()
        self.conv1 = nn.Conv2d(1,64,kernel_size=7, stride=2, padding=3)
        self.convgra = nn.Conv2d(8, 64, kernel_size=7, padding=2, stride=3)
        self.maxp1 = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        self.resn1 = basic_block(64)
        self.resn2 = basic_block(64)
        self.resn3 = basic_block2(64,128)
        self.resn4 = basic_block(128)
        self.resn5 = basic_block2(128,256)
        self.resn6 = basic_block(256)
        self.resn7 = basic_block2(256,512)
        self.resn8 = basic_block(512)
        self.avgp1 = nn.AvgPool2d(7)
        self.avgp2 = nn.AvgPool2d(5)
        self.fullc = nn.Linear(512,1000)
        self.lin3 = nn.Linear(3000, num_classes)
    def forward(self, img, freq, gra) :
        in_size = img.size(0)
        img = self.maxp1(F.relu(self.conv1(img)))
        img = self.resn1(img)
        img = self.resn2(img)
        img = self.resn3(img)
        img = self.resn4(img)
        img = self.resn5(img)
        img = self.resn6(img)
        img = self.resn7(img)
        img = self.resn8(img)
        img = self.avgp1(F.relu(img))
        img = img.view(in_size,-1)
        img = self.fullc(img)

        in_size = freq.size(0)
        freq = self.maxp1(F.relu(self.conv1(freq)))
        freq = self.resn1(freq)
        freq = self.resn2(freq)
        freq = self.resn3(freq)
        freq = self.resn4(freq)
        freq = self.resn5(freq)
        freq = self.resn6(freq)
        freq = self.resn7(freq)
        freq = self.resn8(freq)
        freq = self.avgp1(F.relu(freq))
        freq = freq.view(in_size,-1)
        freq = self.fullc(freq)


        in_size = gra.size(0)
        gra = self.maxp1(F.relu(self.convgra(gra)))
        gra = self.resn1(gra)
        gra = self.resn2(gra)
        gra = self.resn3(gra)
        gra = self.resn4(gra)
        gra = self.resn5(gra)
        gra = self.resn6(gra)
        gra = self.resn7(gra)
        gra = self.resn8(gra)
        gra = self.avgp2(F.relu(gra))
        gra = gra.view(in_size,-1)
        gra = self.fullc(gra)


        x = torch.concat((img,freq),1)
        x = torch.concat((x,gra),1)


        x = self.lin3(x)
        return x