import dataloader
import os
import numpy

from dataloader import myDataSet

from torch.utils.data import Dataset
from torch.utils.data import DataLoader
from torchvision import transforms
import torch.nn.functional as F
import torch
from model import mynet
if __name__ == '__main__':

    data_transform = transforms.Compose([
        transforms.Resize(size=(256,256)),
        transforms.ToTensor(),
        transforms.Normalize([0.5], [0.5])
    ])
    
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    # device = torch.device("cpu")
    # net = easyNet(num_classes=3)
    net = mynet(num_classes=3)
    state_dict = torch.load('model.pth')
    sum = 0
    net.load_state_dict(state_dict)
    net = net.to(device)
    # CatAndDog = myDataSet("D:/blenderdataset/dataxx2/test", data_transform)
    CatAndDog = myDataSet("E:/realtrain/test", data_transform)
    cadSet = DataLoader(CatAndDog, batch_size=1, shuffle=False)
    for batch_idx, (img, freq, gra, label) in enumerate(cadSet):
        img = img.to(device)
        freq = freq.to(device)
        gra = gra.to(device)
        label = label.to(device)
        testlable = net(img, freq, gra)
        # testlable = net(img)
        probabilities = F.softmax(testlable, dim=1)
        predicted_class = torch.argmax(probabilities).item()
        if predicted_class == label[0]:
            print(sum)
            sum = sum + 1
        print(predicted_class,testlable,label)
    print("end")
    print(sum)